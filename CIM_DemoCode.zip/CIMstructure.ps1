﻿##
## CIM structure demo 
##    PowerShell Day UK 2018
##
##    Richard Siddaway
##

Get-CimClass -ClassName *provider*

Get-CimInstance -ClassName __Win32Provider | 
sort Name | select Name

Get-CimInstance -ClassName __NAMESPACE -Namespace root | 
sort Name

## root\cimv2 is default namespace for PowerShell
##
Get-CimClass -ClassName *service* 

## alternatively
Get-WmiObject -Namespace root -Class *service* -Recurse -List

$class = Get-CimClass -ClassName Win32_Service
$class

## properties
$class.CimClassProperties

## class key
foreach ($property in $class.CimClassProperties){
  $property | select -ExpandProperty Qualifiers |
  foreach {
    if ($_.Name -eq 'key'){$property}
  }
}

## methods
$class.CimClassMethods
$class.CimClassMethods['Create'].Parameters

## instances
Get-CimInstance -ClassName Win32_Service

## events
Get-CimClass -ClassName *event*

Get-CimClass -ClassName __Instance*event

####################################################################################################
##
##  CIM events
##   known as Indications when dealing with CIM cmdlets
##
####################################################################################################
##
## CIM classes that deal with general events
##  
Get-CimClass -ClassName CIM_Inst*


<#

 example of using CIM_Inst* in demo code

  also find classes for specific events such as

  Win32_ProcessTrace
  Win32_ProcessStartTrace
  Win32_ProcessStopTrace

#>


#####################
##
## Event registrations are lost when close 
##  PowerShell session
##
## option: 
## WMI permament events
## My opinion permanent events are more trouble
##  than they're worth