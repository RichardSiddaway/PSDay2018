﻿####################################################################################################
##
##  CIM events
##   known as Indications when dealing with CIM cmdlets
##
####################################################################################################
##
## CIM classes that deal with general events
##  
Get-CimClass -ClassName CIM_Inst*
## lets drill in a bit
Get-CimClass -ClassName CIM_Inst* |
foreach {
    if ($_.CimClassQualifiers['Indication'].Value){
        $_.CimClassQualifiers['Description'].Value
    }
}

## in use
$query = "SELECT * FROM CIM_InstModification WHERE TargetInstance ISA 'Win32_LocalTime'"
Register-CimIndicationEvent -Query $query -SourceIdentifier 'Timer'

## see results with Get-Event
Clear-Host
Get-Event -SourceIdentifier 'Timer' | Select-Object -Last 3
Start-Sleep -Seconds 10

Get-Event -SourceIdentifier 'Timer' | Select-Object -Last 3
Start-Sleep -Seconds 10

Get-Event -SourceIdentifier 'Timer' | Select-Object -Last 3

##
## lets stop that
Unregister-Event -SourceIdentifier 'Timer'
## check ended
Get-Event -SourceIdentifier 'Timer' | Select-Object -Last 1
## double check
Get-Event -SourceIdentifier 'Timer' | Select-Object -Last 1

## clear events
Get-Event -SourceIdentifier 'Timer' | Remove-Event
Get-Event -SourceIdentifier 'Timer'