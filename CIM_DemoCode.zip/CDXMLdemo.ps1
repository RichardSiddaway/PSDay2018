﻿##
## CDXML demo 
##    PowerShell Day UK 2018
##
##    Richard Siddaway
##
##    these modules only in Windows 8 and later
##
Get-ChildItem -Path C:\Windows\System32\WindowsPowerShell\v1.0\Modules\* -Recurse -Filter *.CDXML | 
select Fullname

##
## using module 
##   similar ideas with storage module
Get-NetAdapter | sort ifIndex

## using trditional CIM class
##  you can match information - just
##  but its a lot of work
##  Windows 7 \ 2008 \ 2008 R2   out of support January 2020 
Get-CimInstance -ClassName Win32_NetworkAdapter

## only relevant adapaters
## show ifIndex
Get-CimInstance -ClassName Win32_NetworkAdapter -Filter "NetEnabled = 'True'" | 
sort InterfaceIndex | 
Format-Table InterfaceIndex, DeviceID, Name, AdapterType, ServiceName

## cf get-netadapter
Get-NetAdapter | sort ifIndex

## match display
## rename fields
Get-CimInstance -ClassName Win32_NetworkAdapter -Filter "NetEnabled = 'True'" | 
sort InterfaceIndex | 
Format-Table @{N='Name'; E={$_.NetConnectionID}}, 
@{N='InterfaceDescription'; E={$_.Name}}, 
@{N='ifIndex'; E={$_.InterfaceIndex}}, 
@{N='Status'; E={if ($_.NetConnectionStatus -eq 2){'Up'}else{'Down'}}}, MACAddress, 
@{N='Link(Mbps)'; E={$_.Speed / 1000000}}

## cf get-netadapter
Get-NetAdapter | sort ifIndex

##
##  Ip addresses
##
Get-NetIPAddress -AddressFamily IPv4   | select InterfaceAlias, InterfaceIndex, IPAddress

## this is about as close as you can get
Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPenabled = $true" | 
sort InterfaceIndex | 
select Description, InterfaceIndex, IPAddress

## linking IP address to adapter  
Get-NetAdapter |
foreach {
 $props = [ordered]@{
   Name = $_.Name
   Status = $_.Status
   MacAddress = $_.MacAddress
   IPAddress = Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4

 }
 New-Object -TypeName PSobject -Property $props
}

## for CIM classes use association
Get-CimInstance -ClassName Win32_NetworkAdapter -Filter "NetEnabled = 'True'" |
foreach {
  $props = [ordered]@{
   Name = $_.NetConnectionID
   Status = if ($_.NetConnectionStatus -eq 2){'Up'}else{'Down'}
   MacAddress = $_.MacAddress
   IPAddress = Get-CimAssociatedInstance -InputObject $_ -ResultClassName Win32_NetworkAdapterConfiguration | 
               select -ExpandProperty IPAddress | select -First 1

 }
 New-Object -TypeName PSobject -Property $props
} 
