﻿##
## CIM demo 
##    PowerShell Day UK 2018
##
##    Richard Siddaway
##

##
##  start W16DC01, W10PRV01, vEOS

Set-Location C:\MyData\PSDay2018\CIM\Code

##
##  back in the dark ages
##
Get-Content .\getwmi.vbs
cscript getwmi.vbs

##
## through the hoops
##  to get the date
##
Get-Content getwmi2.vbs
cscript getwmi2.vbs

##
##  WMI cmdlet
##
Get-WmiObject -Class Win32_OperatingSystem |
select Caption, Installdate, LastBootUpTime, version, OSArchitecture

##  format date
Get-WmiObject -Class Win32_OperatingSystem |
select Caption, 
@{N='InstallDate'; E={$_.ConvertToDateTime($_.Installdate)}}, 
@{N='BootTime'; E={$_.ConvertToDateTime($_.LastBootUpTime)}}, 
version, OSArchitecture

##
##  CIM does the work
##
Get-CimInstance -ClassName Win32_OperatingSystem |
select Caption, Installdate, LastBootUpTime, version, OSArchitecture

##
## inert object
##
$class = Get-CimClass -ClassName Win32_OperatingSystem
$class.CimClassMethods

Get-CimInstance -ClassName Win32_OperatingSystem | Get-Member