﻿##
## CIM event demo 
##    PowerShell Day UK 2018
##
##    Richard Siddaway
##

##  RUN FROM COMMAND LINE

param (
 [string]$folder
)

function add-drive {
[CmdletBinding()]
param (
 [string]$drive 
)
 Write-Warning -Message "Drive $($drive) Added"

 Write-Warning -Message "Deleting Files from $($drive) "
 Remove-Item -Path $drive -Recurse -Force -Verbose
 
 Write-Warning -Message "Copying Files from $folder to Drive $($drive) "
 Copy-Item -Path $folder -Destination $drive -Recurse -Force -Verbose
 Write-Warning -Message "Finished Copying Files to Drive $($drive)"
}

function remove-drive {
param (
 [string]$drive
)
 Write-Warning -Message "Drive $($drive) Removed"
} 

 
if (-not (Test-Path $folder)){Throw "Folder $($folder) not found"}

if (Get-EventSubscriber | 
 where {$_.SourceIdentifier -eq "usb plug in"}) {
 Unregister-Event -SourceIdentifier "usb plug in" 
}

if (Get-EventSubscriber | 
 where {$_.SourceIdentifier -eq "usb plug out"}) {
 Unregister-Event -SourceIdentifier "usb plug out" 
}

$queryIn = "SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_Volume' AND TargetInstance.DriveType=2"
$queryOut = "SELECT * FROM Win32_VolumeChangeEvent WHERE EventType=3"

$actionIn = {
   add-drive -drive $($event.SourceEventArgs.NewEvent.TargetInstance.DriveLetter) 
}

$actionOut = {
  remove-drive -drive $($event.SourceEventArgs.NewEvent.DriveName)
}

##
## could have used Register-WmiEvent with same syntax
##

Register-CimIndicationEvent -Query $queryIn -SourceIdentifier "usb plug in" -Action $actionIn 
Register-CimIndicationEvent -Query $queryOut -SourceIdentifier "usb plug out" -Action $actionOut

<#
. .\autocopy.ps1 C:\test\
. .\autocopy.ps1 C:\test2\
Get-EventSubscriber | Unregister-Event
Get-Job
Get-Job | Remove-Job
#>


#####################
##
## Event registrations are lost when close 
##  PowerShell session
##
## option: 
## WMI permament events
## My opinion permanent events are more trouble
##  than they're worth