﻿##
## CIM management of network switch demo 
##    PowerShell Day UK 2018
##
##    Richard Siddaway
##

## 
##  used:
##    vEOS-lab-4.15.10M.vmdk
##    Aboot-veos-8.0.0.iso
## 
## https://eos.arista.com/veos-lab-on-hyper-v/
## https://www.powershellmagazine.com/2014/09/02/omi-and-networkswitch-module/

<#

## stop VM then
Add-VMNetworkAdapter -VMName vEOS -SwitchName LAN -IsLegacy:$true -Name Eth1
Add-VMNetworkAdapter -VMName vEOS -SwitchName LAN -IsLegacy:$true -Name Eth2
Add-VMNetworkAdapter -VMName vEOS -SwitchName LAN -IsLegacy:$true -Name Eth3


to save switch settings after on switch configuration
copy running-config startup-config
#>

##
##  connect to vEOS switch
##

$cred = Get-Credential root
$opt = New-CimSessionOption -UseSsl -NoEncryption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
$cs = New-CimSession -ComputerName 10.10.54.30 -Credential $cred -SessionOption $opt -Authentication Basic

## Now have a WSMAN connection
##  to a Linux based network switch!!!
## can do same with LInux server or ESX
##  for based device Linux using OMI

## this fails
##   OMI issue
Get-CimClass -CimSession $cs -ClassName CIM_*

## this works
Get-CimClass -CimSession $cs -ClassName CIM_EthernetPort

Get-CimClass -CimSession $cs -ClassName Arista_EthernetPort

$class = Get-CimClass -CimSession $cs -ClassName Arista_EthernetPort
$class.CimClassProperties | Select-Object Name
$class.CimClassMethods

Get-CimInstance -CimSession $cs -ClassName Arista_EthernetPort |
Format-Table -AutoSize DeviceId, OperationalStatus, EnabledState

## WMF 5.0 NetworkSwitch module
Get-Command -Module NetworkSwitchManager

Get-NetworkSwitchFeature -CimSession $cs

## Notice working over CIM!
## Notice class
Get-NetworkSwitchFeature -CimSession $cs | select -First 1 | Format-List *

Get-NetworkSwitchGlobalData -CimSession $cs | Format-List *

Get-NetworkSwitchVlan -CimSession $cs | Format-List *

Get-NetworkSwitchEthernetPort -CimSession $cs

# Notice class
Get-NetworkSwitchEthernetPort -PortNumber 1 -CimSession $cs | Format-List *
Get-NetworkSwitchEthernetPort -CimSession $cs | Select-Object Name, EnabledState, PortNumber  

Disable-NetworkSwitchEthernetPort -PortNumber 1 -CimSession $cs 
Get-NetworkSwitchEthernetPort -CimSession $cs | Select-Object Name, EnabledState, PortNumber  

Enable-NetworkSwitchEthernetPort -PortNumber 1 -CimSession $cs
Get-NetworkSwitchEthernetPort -CimSession $cs | Select-Object Name, EnabledState, PortNumber  

Save-NetworkSwitchConfiguration -CimSession $cs -Verbose

## clean up
Get-CimSession | Remove-CimSession